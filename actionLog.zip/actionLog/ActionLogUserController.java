/**
 * 
 */
package mkcl.oesserver.controllers;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Properties;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeansException;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import mkcl.oes.commons.SessionHelper;
import mkcl.oespcs.model.Client;
import mkcl.oesserver.services.OESClientUserServicesImpl;
import mkcl.os.apps.model.Constants;
import mkcl.os.apps.model.Pagination;
import mkcl.os.apps.utilities.MKCLUtility;
import mkcl.os.apps.utilities.PaginationHelper;

/**
 * @author virajd
 * 
 */
@Controller
@RequestMapping("actionLog")
public class ActionLogUserController extends PaginationHelper implements
		ApplicationContextAware {

	private static final Logger LOGGER = LoggerFactory.getLogger(ActionLogUserController.class);
	private OESClientUserServicesImpl oesClientUserServicesImplObj;
	
	
	private static final String PAGINATION = "pagination";
	private static final String USERLIST = "UserList";
	
	/*
	 * Get errorPage and exception string constants from constants class.
	 */
	private static final String ERRORPAGE = Constants.ERRORPAGE;
	private static final String EXCEPTIONSTRING = Constants.EXCEPTIONSTRING;

	private static final String OESCLIENTUSERLISTVIEW = "actionLog/actionLogUserList";

	public static final Pattern VALID_PASSWORD_REGEX = 
			Pattern.compile("^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{8,}$");
	
	public static final Pattern VALID_EMAIL_ADDRESS_REGEX =
		    Pattern.compile("^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,6}$", Pattern.CASE_INSENSITIVE);
	
	public static final Pattern VALID_USERID_REGEX = Pattern.compile("^(?=.{6,50}$)(?![_.@])(?!.*[_.@]{2})[a-zA-Z0-9._@]+(?<![_.@])$"); 
	
	public static final Pattern VALID_MOBILE_NUMBER = Pattern.compile("^[0-9]{10}$");
	
	public static final Pattern VALID_ISD_CODE = Pattern.compile("^\\+\\d{2,3}$");
	
	/**
	 * Method to bind date with with given format.
	 * 
	 * @param dataBinder
	 * @param locale
	 */
	@InitBinder
	public void initBinder(WebDataBinder dataBinder, Locale locale,
			HttpServletRequest request) {
		Properties properties = null;
		String dateFormatString;
		SimpleDateFormat dateFormat;

		properties = MKCLUtility.loadMKCLPropertiesFile();

		dateFormatString = properties.getProperty("global.dateFormat");

		dateFormat = new SimpleDateFormat(dateFormatString);
		dateFormat.setLenient(false);
		dataBinder.registerCustomEditor(Date.class, new CustomDateEditor(
				dateFormat, true));
	}

	/**
	 * Get method for Client User List
	 * @param model
	 * @param request
	 * @param locale
	 * @return String this returns the path of a view
	 */
	@RequestMapping(value = { "/actionLogUserList" }, method = RequestMethod.GET)
	public String listGet(Model model, HttpServletRequest request, Locale locale) {
		LoggerFactory.getLogger(ActionLogUserController.class).debug(
				"Method Started");
		try {

			if (request.getSession().getAttribute("loginStatus") == null) {
				return "redirect:../login/loginpage";
			}
			// 1 Call to method add message.
			addMessage(request, model, locale);
			
			// 2 Get searchText.
			String searchText = request.getParameter("searchText");

			// get OES client id from session
			Client client = SessionHelper.getClient(request);
			model.addAttribute("clientID", client.getClientID());

			// 3 Get Object list.
			Pagination pagination = new Pagination();
			pagination.setPropertyName("");
			pagination.setListName(USERLIST);
			if (searchText != null && !(searchText.equals(""))) {
				pagination.setPropertyName("");
				oesClientUserServicesImplObj.pagination(null, pagination,
						searchText, model);
			} else {
				oesClientUserServicesImplObj.pagination(null, pagination,
						null, model);
			}
			return OESCLIENTUSERLISTVIEW;
		} catch (Exception ex) {

			LoggerFactory.getLogger(ActionLogUserController.class).error(
					ex.getMessage());
			model.addAttribute(Constants.EXCEPTIONSTRING, ex.getMessage());
			return Constants.ERRORPAGE;
		}
	}

	
	/**
	 * Post method for User List Pagination - Previous
	 * @param model
	 * @param pagination
	 * @param request
	 * @param searchText
	 * @return String this returns the path of a view
	 */
	@RequestMapping(value = { "/prev" }, method = RequestMethod.POST)
	public String prevPost(Model model,
			@ModelAttribute(PAGINATION) Pagination pagination,
			HttpServletRequest request, String searchText) {

		// get OES client id from session
		Client client = SessionHelper.getClient(request);
		model.addAttribute("clientID", client.getClientID());

		pagination.setListName(USERLIST);
		try {
			if (searchText != null && !(searchText.equals(""))) {
				pagination.setPropertyName("id");
				oesClientUserServicesImplObj.paginationPrev(null, pagination,
						searchText, model);
			} else {
				oesClientUserServicesImplObj.paginationPrev(null, pagination,
						searchText, model);
			}
		} catch (Exception ex) {
			LOGGER.error("exception while calling paginationPrev method.");
		}
		return OESCLIENTUSERLISTVIEW;

	}

	/**
	 * Post method for User List Pagination - Next
	 * @param model
	 * @param pagination
	 * @param request
	 * @param searchText
	 * @return String this returns the path of a view
	 */
	@RequestMapping(value = { "/next" }, method = RequestMethod.POST)
	public String nextPost(Model model,
			@ModelAttribute(PAGINATION) Pagination pagination,
			String searchText, HttpServletRequest request) {

		// get OES client id from session
		Client client = SessionHelper.getClient(request);
		model.addAttribute("clientID", client.getClientID());

		pagination.setListName(USERLIST);
		try {
			if (searchText != null && !(searchText.equals(""))) {
				pagination.setPropertyName("id");
				oesClientUserServicesImplObj.paginationNext(null, pagination,
						searchText, model);
			} else {
				oesClientUserServicesImplObj.paginationNext(null, pagination,
						searchText, model);
			}
		} catch (Exception ex) {
			LOGGER.error("exception while calling nextPost OESCLIENT User Controller  method.");
		}
		return OESCLIENTUSERLISTVIEW;
	}

	



	/**
	 * Get method to Cancel Client User List
	 * @param model
	 * @return String this returns the path of a view
	 */
	@RequestMapping(value = { "/cancel" }, method = RequestMethod.GET)
	public String cancelGet(Model model) {
		try {
			return "redirect:AccreditationClientUserlist";
		} catch (Exception ex) {
			LOGGER.error("Excption while cancelGet in OESClientController:"+ex.getMessage());
			model.addAttribute(EXCEPTIONSTRING, ex);
			return ERRORPAGE;
		}
	}

	
	/**
	 * Adds the message.
	 *
	 * @param request the request
	 * @param model the model
	 * @param locale the locale
	 */
	protected void addMessage(HttpServletRequest request, Model model,
			Locale locale) {
		String messageId = request.getParameter("messageid");
		if (messageId != null && messageId.trim().length() != 0) {
			MKCLUtility.addMessage(Integer.parseInt(messageId), model, locale);
		}
	}

	
	public void setApplicationContext(ApplicationContext applicationContext)throws BeansException {
		oesClientUserServicesImplObj = (OESClientUserServicesImpl) applicationContext.getBean("OESClientUserService");

	}

}
